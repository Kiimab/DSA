public class ExtendedQueueException extends RuntimeException {

  public ExtendedQueueException(String s) {
    super(s);
  }  // end constructor
}  // end ExtendedQueueException