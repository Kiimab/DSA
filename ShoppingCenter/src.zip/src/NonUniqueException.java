
public class NonUniqueException
	extends RuntimeException{

	public NonUniqueException(String s)
    {
        super(s);
    }
}
