
public class InvalidException 
	extends RuntimeException {
	
	public InvalidException(String s)
    {
        super(s);
    }
}
